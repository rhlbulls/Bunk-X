import requests
from bs4 import BeautifulSoup
from flask import Flask,request
import json




def data(rollno,password):
    l={}
    attendance=[]
    login_data={
        'rdolst': 'S',
        'txtusercheck': rollno,       #ROLL NUMBER
        'txtpwdcheck': password,       #Password
        'abcd3': 'Login',
        '__VIEWSTATE': 'kwawxEMW7e+fBH7LuFLWzLc0zRT+nNPcholutnaFQy4gO6devP3U9o6ZnQZYmvSo++dsrW5AmJxMhx1Ylx3HGW+6S/Ob2cZilyo2YwPTgfITIUNyrpPVSobFNuhYnyUVZrONsav0lMdtk2LShQbdTKCIhOse0csm4b6nB1QzFPWdVpx3M7gdn5lybOVYO/Lr7wW1zi1HxFi7PMzB4+OlIL5SNQaIkFhAngHh6Po3+Rs=',
        '__EVENTVALIDATION': 'KcBL7rO1L1x+xn0VCG307E1Zkk0Yoj9QrdspieEGQiErSdNEJoj90PwBeFvXicLY8njg6Akdt/+O0FIkuAIntFQ7evpYqGRh5kOAjBI8s4YreS55muhnpet0oLabvf5KMw6nkr9EV9eZDRx9NutM/l0Hc9T4WUiy/FWlJnpQ+PFVvPM9uNqKt+Ryizb7j+RVcC95AIIdoOpM1ftcLTezrX2/Wq2qhheA6h6lxYlTuoIC7O36zrEUJdUKmyiGbFzBskpm0ejee49j/lF4WU9WsPxsAVNJK980LyQ8ZI4Rzpg=',
        }

    with requests.Session() as s:
    
    #Validating the form
        subjects=[]
        url='https://ecampus.psgtech.ac.in/studzone2/'
        r = s.get(url)
        soup=BeautifulSoup(r.content,'html5lib')
        login_data['__VIEWSTATE']=soup.find('input',attrs={'name':'__VIEWSTATE'})['value']
        login_data['__EVENTVALIDATION']=soup.find('input',attrs={'name':'__EVENTVALIDATION'})['value']
        r=s.post(url,data=login_data)
        
        #Getting the data from site
        
        r=s.get('https://ecampus.psgtech.ac.in/studzone2/AttWfPercView.aspx')   
        soup=BeautifulSoup(r.content,'html.parser')
        name=soup.find_all('td')
        count=0
        #list for storing data
        for i in name:
            #print(count)
            #print(i.string)
            
            if(count==27):
                l['name']=(i.string)
            elif (count==30):
                l['programme']=(i.string)
            elif(count==33):
                l['rollno']=(i.string)
            elif(count==36):
                l['sem']=(i.string)           
            elif(count>=40 and count<=129):
                attendance.append(i.string)
                l['attendance']=attendance
            count=count+1
            
        r=s.get('https://ecampus.psgtech.ac.in/studzone2/CAMarks_View.aspx')
        soup=BeautifulSoup(r.content,'html.parser')
        name=soup.find_all('td')
        count=0
        for i in name:
            if count==52:
                
                
                subjects.append(i.string)
            if count==60:
              
                subjects.append(i.string)
            if count==68:
               
                subjects.append(i.string)
            if count==76:
             
                subjects.append(i.string)
            if count==84:
              
                subjects.append(i.string)
                
            if count==104:
               
                subjects.append(i.string)
            if count==111:
              
                subjects.append(i.string)
            if count==118:
               
                subjects.append(i.string)
            count=count+1
     
        l['subjects']=subjects
        #print(json.dumps(l))
        #soup=BeautifulSoup(r.content,'html5lib')
        #print(soup.prettify())
        #print(l)    
        return(json.dumps(l))



application=Flask(__name__)

@application.route('/',methods=['GET'])
def stud_attendance():
    a=request.args['cred']
    #return data('18pw28','12feb01')
    a=a.split(' ')
    return (data(a[0],a[1]))

if __name__ == '__main__':
    application.run()

